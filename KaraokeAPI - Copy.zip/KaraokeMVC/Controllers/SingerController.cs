﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using KaraokeMVC.Models;
namespace KaraokeMVC.Controllers
{
    public class SingerController : Controller
    {
        // GET: Singer
        public ActionResult ListSinger()
        {
            SingerBusinessLayer s = new SingerBusinessLayer();
            List<Singer> lst = new List<Singer>();
            lst = s.GetListSinger();
            return View(lst);
        }

        [HttpGet]
        public ActionResult ListSongOfSinger(string ID)
        {
            SingerBusinessLayer siBal = new SingerBusinessLayer();
            List<Song> lst = siBal.GetSongOfSinger(ID);
            return View(lst);
           
        }

        [HttpGet]
        public ActionResult CreateSinger()
        {
            return View();
        }
        public ActionResult CreateSinger(Singer si)
        {
            SingerBusinessLayer s = new SingerBusinessLayer();
            s.CreateSinger(si);

            List<Singer> lst = s.GetListSinger();

            return View("ListSinger",lst);
        }



        [HttpGet]
        public ActionResult EditSinger(string id)
        {
            SingerBusinessLayer SBal = new SingerBusinessLayer();
            Singer s = SBal.GetListSinger().Where(x => x.SingerID == id).FirstOrDefault();
            return View(s);
        }
        public ActionResult EditSinger(Singer si)
        {
            SingerBusinessLayer s = new SingerBusinessLayer();
            s.EditSinger(si);
            List<Singer> lst = s.GetListSinger();

            return View("ListSinger", lst);
        }



        public ActionResult DeleteSinger(string id)
        {
            SingerBusinessLayer s = new SingerBusinessLayer();
            s.DeleteSinger(id);
            List<Singer> lst = s.GetListSinger();
            return View("ListSinger", lst);
        }


    }
}