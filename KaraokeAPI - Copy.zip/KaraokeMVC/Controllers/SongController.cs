﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using KaraokeMVC.Models;

namespace KaraokeMVC.Controllers
{
    public class SongController : Controller
    {
        // GET: Song
        public ActionResult ListSong()
        {
            SongBusinessLayer s = new SongBusinessLayer();
            List<SongViewModel> lst = s.getListSong();
            return View("ListSong",lst);
        }

        [HttpGet]
        public ActionResult Create()
        {
            AuthorBusinessLayer AuBal = new AuthorBusinessLayer();
            GenreBusinessLayer GeBal = new GenreBusinessLayer();
            SingerBusinessLayer SiBal = new SingerBusinessLayer();
            ViewData["ListSinger"] = SiBal.GetListSinger();
            ViewData["ListAuthor"] = AuBal.GetListAuthor();
            ViewData["ListGenre"] = GeBal.GetGenre();
            return View();
        }
        [HttpPost]
        public ActionResult Create(SongCreate s, string _listID)
        {
            string[] list = _listID.Split(',');
            s.ListSinger = list;
            SongBusinessLayer SoBal = new SongBusinessLayer();
            SoBal.CreateSong(s);
            List<SongViewModel> lst = SoBal.getListSong();
            return View("ListSong", lst);
        }


        public ActionResult Delete(string id)
        {
            SongBusinessLayer SoBal = new SongBusinessLayer();
            SoBal.DeleteSong(id);
            List<SongViewModel> lst = SoBal.getListSong();
            return View("ListSong", lst);
        }


        [HttpGet]
        public ActionResult EditSong(string id)
        {
            AuthorBusinessLayer AuBal = new AuthorBusinessLayer();
            GenreBusinessLayer GeBal = new GenreBusinessLayer();
            SingerBusinessLayer SiBal = new SingerBusinessLayer();
            ViewData["ListSinger"] = SiBal.GetListSinger();
            ViewData["ListAuthor"] = AuBal.GetListAuthor();
            ViewData["ListGenre"] = GeBal.GetGenre();
            SongBusinessLayer SongBal = new SongBusinessLayer();
            List<SongViewModel> lst = SongBal.getListSong();
            return View(lst.Find(x => x.SongID == id));
        }
        [HttpPost]
        public ActionResult EditSong(SongCreate s, string _listID)
        {
            SongBusinessLayer SongBal = new SongBusinessLayer();
            SongBal.DeleteSong(s.SongID);
            string[] list = _listID.Split(',');
            s.ListSinger = list;
            SongBal.CreateSong(s);
            List<SongViewModel> lst = SongBal.getListSong();
            return View("ListSong", lst);
        }


        [HttpGet]
        public ActionResult Detail(string id)
        {
            SongBusinessLayer SongBal = new SongBusinessLayer();
            List<SongViewModel> lst = SongBal.getListSong();
            return View(lst.Find(x => x.SongID == id));
        }
    }
}