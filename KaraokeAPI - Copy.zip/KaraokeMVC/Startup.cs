﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(KaraokeMVC.Startup))]
namespace KaraokeMVC
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
        }
    }
}
