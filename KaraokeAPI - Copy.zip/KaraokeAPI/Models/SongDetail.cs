namespace KaraokeMVC.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class SongDetail
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string SongID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(50)]
        public string SingerID { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(50)]
        public string AuthorID { get; set; }

        public virtual Author Author { get; set; }

        public virtual Singer Singer { get; set; }

        public virtual Song Song { get; set; }
    }
}
