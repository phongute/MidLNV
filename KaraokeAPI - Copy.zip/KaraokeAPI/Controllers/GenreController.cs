﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using KaraokeMVC.Models;
namespace KaraokeMVC.Controllers
{
    public class GenreController : ApiController
    {
        Karaoke k = new Karaoke();
        public List<Genre> GetGenre()
        {
            List<Genre> lst = new List<Genre>();
            var query = (from g in k.Genres select g).ToList();
            foreach(var q in query)
            {
                lst.Add(new Genre
                {
                    GenreID = q.GenreID,
                    GenreName = q.GenreName,
                });
            }
            return lst;
        }
        public List<Song> GetSongOfGenre(string id)
        {
            List<Genre> lst = new List<Genre>();
            var query = (from g in k.Genres
                         join so in k.Songs on g.GenreID equals so.GenreID
                         where so.GenreID == id
                         select so).ToList();
            List<Song> lstSong = new List<Song>();
            foreach(var item in query)
            {
                lstSong.Add(new Song
                {
                    SongID = item.SongID,
                    SongName = item.SongName,
                    GenreID = item.GenreID,
                    DatePost = item.DatePost,
                    ViewCount = item.ViewCount,
                });
            }
            return lstSong;
        }
    }
}
