﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using KaraokeMVC.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace KaraokeMVC.Controllers
{
    public class SongController : ApiController
    {
        Karaoke k = new Karaoke();

        [HttpPost] 
        public IHttpActionResult PostSong(SongCreate sv)
        {
            Song s = new Song
            {
                SongID = sv.SongID,
                SongName = sv.SongName,
                GenreID = sv.GenreID,
                DatePost = DateTime.Now,
                ViewCount = 0,
            };
            k.Songs.Add(s);
            k.SaveChanges();
            for(int i=0;i<sv.ListSinger.Length;i++)
            {
                SongDetail sd = new SongDetail
                {
                    SongID = sv.SongID,
                    SingerID = sv.ListSinger[i],
                    AuthorID = sv.AuthorID,
                };
                k.SongDetails.Add(sd);
                k.SaveChanges();
            }
            return CreatedAtRoute("DefaultAPI", new { id = s.SongID }, s);
        }




        public List<Singer> GetListSingerBySong(string id)
        {
            var query = (from si in k.Singers
                         join so in k.SongDetails on si.SingerID equals so.SingerID
                         where so.SongID == id
                         select si).ToList();
            List<Singer> lst = new List<Singer>();
            foreach (Singer si in query)
                lst.Add(new Singer
                {
                    SingerID = si.SingerID,
                    SingerName = si.SingerName,
                    Age = si.Age,
                });
            return lst;
        }

        public List<SongViewModel> GetListSong()
        {
            var query = k.Database.SqlQuery<SongViewModel>("select * from GetSongDistinct()").ToList();
            List<SongViewModel> lst = new List<SongViewModel>();

            foreach (var p in query)
            {
                lst.Add(new SongViewModel
                {
                    SongID = p.SongID,
                    SongName = p.SongName,
                    GenreID = p.GenreID,
                    GenreName = p.GenreName,
                    AuthorID = p.AuthorID,
                    AuthorName = p.AuthorName,
                    DatePost = DateTime.Now,
                    ViewCount = 0,
                    ListSinger=GetListSingerBySong(p.SongID),
                });            
            }
            return lst;
        }



        [HttpDelete]
        public IHttpActionResult DeleteSong(string id)
        {
            
            List<SongDetail> s1 = k.SongDetails.Where(y => y.SongID == id).ToList();
            foreach(var p in s1)
            {  
                SongDetail sd = k.SongDetails.Where(z => z.SongID == p.SongID).FirstOrDefault();
                k.SongDetails.Remove(sd);
                k.SaveChanges();
            }
            Song s = k.Songs.Where(x => x.SongID == id).FirstOrDefault();
            k.Songs.Remove(s);
            k.SaveChanges();
            return Ok();
        }


    }
}
