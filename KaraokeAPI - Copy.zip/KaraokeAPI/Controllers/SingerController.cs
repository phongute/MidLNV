﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using KaraokeMVC.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace KaraokeMVC.Controllers
{
    public class SingerController : ApiController
    {
        Karaoke k = new Karaoke();

        public List<Singer> GetSinger()
        {
            var query = (from si in k.Singers select si).ToList();
            List<Singer> lst = new List<Singer>();
            foreach(var q in query)
            {
                lst.Add(new Singer
                {
                    SingerID = q.SingerID,
                    SingerName = q.SingerName,
                    Age = q.Age,
                });
            }
            return lst;
        }

        public List<Song> GetSongOfSinger(string id)
        {
            var query = (from si in k.Singers
                         join so in k.SongDetails on si.SingerID equals so.SingerID
                         join s in k.Songs on so.SongID equals s.SongID
                         where si.SingerID == id
                         select s).ToList();
            List<Song> lst = new List<Song>();
            foreach(var p in query)
            {
                lst.Add(new Song
                {
                    SongID = p.SongID,
                    SongName = p.SongName,
                });
            }
            return lst;
        }

        [HttpPost]
        public IHttpActionResult PostSinger(SingerViewModel sn)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var s = new Singer() { SingerID = sn.SingerID, SingerName = sn.SingerName, Age = sn.Age };

            k.Singers.Add(s);
            k.SaveChanges();
            return CreatedAtRoute("DefaultAPI", new { id = s.SingerID }, s);
        }


        [HttpPut]
        public IHttpActionResult EditSinger(string id,SingerViewModel s)
        {
            var a = k.Singers.Where(x => x.SingerID == id).FirstOrDefault();
            a.SingerID = s.SingerID;
            a.SingerName = s.SingerName;
            a.Age = s.Age;
            k.SaveChanges();
            return StatusCode(HttpStatusCode.NoContent);

        }


        [HttpDelete]
        public IHttpActionResult DeleteSinger(string id)
        {
            List<SongDetail> s = k.SongDetails.Where(x => x.SingerID == id).ToList();
            List<SongDetail> s1 = (from so in k.SongDetails select so).ToList(); 
            int count = 0;
            foreach(var q in s)
            {
                foreach(var p1 in s1)
                {
                    if (q.SongID == p1.SongID)
                        count++;
                }
                if(count == 1)
                {
                    SongDetail sd = k.SongDetails.Where(x => x.SongID == q.SongID).FirstOrDefault();
                    k.SongDetails.Remove(sd);
                    k.SaveChanges();

                    Song so = k.Songs.Where(x => x.SongID == q.SongID).FirstOrDefault();
                    k.Songs.Remove(so);
                    k.SaveChanges();

                }
            }
            Singer si = k.Singers.Where(x => x.SingerID == id).FirstOrDefault();
            k.Singers.Remove(si);
            k.SaveChanges();
            return Ok();
        }


    }
}
