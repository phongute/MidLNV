﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using KaraokeMVC.Models;
namespace KaraokeMVC.Controllers
{
    public class AuthorController : ApiController
    {
        Karaoke k = new Karaoke();
        public List<Author> GetGenre()
        {
            List<Author> lst = new List<Author>();
            var query = (from g in k.Authors select g).ToList();
            foreach (var q in query)
            {
                lst.Add(new Author
                {
                    AuthorID = q.AuthorID,
                    AuthorName = q.AuthorName,
                });
            }
            return lst;
        }
    }
}
